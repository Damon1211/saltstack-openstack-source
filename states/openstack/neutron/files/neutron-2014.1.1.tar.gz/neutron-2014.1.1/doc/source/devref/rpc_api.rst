Neutron RCP API Layer
=====================
