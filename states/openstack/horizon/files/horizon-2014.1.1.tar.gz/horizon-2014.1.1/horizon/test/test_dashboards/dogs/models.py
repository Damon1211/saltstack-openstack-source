"""
Stub file to work around django bug: https://code.djangoproject.com/ticket/7198
"""
