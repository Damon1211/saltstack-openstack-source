/* Additional JavaScript for dogs. */
