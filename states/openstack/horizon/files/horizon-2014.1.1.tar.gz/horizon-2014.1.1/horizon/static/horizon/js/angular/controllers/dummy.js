/*globals horizonApp*/
(function () {
  'use strict';
  horizonApp.
    controller('DummyCtrl', function () {});
}());
